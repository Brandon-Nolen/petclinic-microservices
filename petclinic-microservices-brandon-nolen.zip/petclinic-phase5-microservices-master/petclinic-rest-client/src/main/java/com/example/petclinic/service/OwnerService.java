package com.example.petclinic.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.security.acl.Owner;

@Service
public class OwnerService {

    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Owner saveOwner(Owner owner) {
        URI uri = URI.create("http://localhost:/ownerapi/owner/addOwner");

        Owner response = restTemplate.postForObject(uri, owner, Owner.class);
        log.info(response.toString());
        return response;
    }
}
