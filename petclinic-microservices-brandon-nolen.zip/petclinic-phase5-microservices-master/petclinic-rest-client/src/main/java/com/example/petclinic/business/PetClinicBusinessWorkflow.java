package com.example.petclinic.business;

import com.example.petclinic.model.Owner;
import com.example.petclinic.service.OwnerService;
import org.springframework.stereotype.Component;

@Component
public class PetClinicBusinessWorkflow {

        OwnerService ownerService;

        public void runBusiness() {
            Owner owner1 = Owner.builder().withId(1L).withName("Homer Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550113").build();
            Owner owner2 = Owner.builder().withId(2L).withName("Marge Simpson").withAddress("742 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9315542334").build();
            Owner owner3 = Owner.builder().withId(3L).withName("")
        }
}
