package com.example.petclinic.business;

import com.example.petclinic.model.*;
import com.example.petclinic.service.OwnerService;
import com.example.petclinic.service.PetService;
import com.example.petclinic.service.VetService;
import com.example.petclinic.service.VisitService;
import org.springframework.stereotype.Component;

import java.util.Date;


@Component
public class PetClinicBusinessWorkflow {

    OwnerService ownerService;
    PetService petService;
    VisitService visitService;
    VetService vetService;

    public PetClinicBusinessWorkflow(OwnerService ownerService, PetService petService, VetService vetService, VisitService visitService) {
        this.ownerService = ownerService;
        this.petService = petService;
        this.visitService = visitService;
        this.vetService = vetService;
    }

    public void runBusiness() {
            Owner owner1 = Owner.builder().withId(1L).withName("Homer Simpson").withAddress("740 Evergreen Terrace").withCity("Springfield").withPhoneNumber("9395550111").build();
            Owner owner2 = Owner.builder().withId(2L).withName("Marge Simpson").withAddress("741 Evergreen Terrace").withCity("Ringfield").withPhoneNumber("9315542334").build();
            Owner owner3 = Owner.builder().withId(3L).withName("BartSimpson").withAddress("742 Evergreen Terrace").withCity("Singfield").withPhoneNumber("9395550112").build();
            Owner owner4 = Owner.builder().withId(4L).withName("Lisa Simpson").withAddress("743 Evergreen Terrace").withCity("Pingfield").withPhoneNumber("9395550113").build();

            ownerService.saveOwner(owner1);
            ownerService.saveOwner(owner2);
            ownerService.saveOwner(owner3);
            ownerService.saveOwner(owner4);

            ownerService.getById(1L);
            ownerService.getAllOwners();

            Pet pet1 = Pet.builder().withId(5L).withName("Strangles").withBirthDate(new Date()).withPetType(PetType.SNAKE).build();
            Pet pet2 = Pet.builder().withId(6L).withName("Mojo").withBirthDate(new Date()).withPetType(PetType.MONKEY).build();

            petService.savePet(pet1);
            petService.savePet(pet2);

            petService.getById(5L);
            petService.getAllPets();

            Visit visit1 = Visit.builder().withDateOfVisit(new Date()).withDescription("Nice Visit!").withPet(pet1).build();
            Visit visit2 = Visit.builder().withDateOfVisit(new Date()).withDescription("Bad Visit!").withPet(pet2).build();

            visitService.saveVisit(visit1);
            visitService.saveVisit(visit2);

            visitService.getAllVisits();

            Vet vet1 = Vet.builder().withName("SuperVet").withSpeciality(Speciality.DENTISTRY).withSpeciality(Speciality.DENTISTRY).withSpeciality(Speciality.SURGERY).withVisit(visit1).build();
            Vet vet2 = Vet.builder().withName("SuperDuperVet").withSpeciality(Speciality.DENTISTRY).withSpeciality(Speciality.SURGERY).withSpeciality(Speciality.RADIOLOGY).withVisit(visit1).build();

            vetService.saveVet(vet1);
            vetService.saveVet(vet2);

            vetService.getAllVets();
        }
}
