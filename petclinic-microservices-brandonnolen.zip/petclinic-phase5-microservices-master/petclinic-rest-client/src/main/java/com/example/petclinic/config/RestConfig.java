package com.example.petclinic.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RestConfig {
}
