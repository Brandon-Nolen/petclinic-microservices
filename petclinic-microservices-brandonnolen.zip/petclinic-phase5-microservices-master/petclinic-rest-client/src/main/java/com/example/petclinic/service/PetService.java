package com.example.petclinic.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.net.URI;
import java.util.List;

import com.example.petclinic.model.Pet;


@Service
public class PetService {

    private static final Logger log = LoggerFactory.getLogger(PetService.class);

    RestTemplate restTemplate;

    public PetService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Pet savePet(Pet pet) {
        URI uri = URI.create("http://localhost:8082/help/pet/addPet");

        Pet response = restTemplate.postForObject(uri, pet, Pet.class);
        String output = response.toString();
        log.info(output);
        return response;
    }

    public Pet getById(Long id) {
        String url = "http://localhost:8082/help/pet/getPetById/" + id;
        Pet response = restTemplate.getForObject(url, Pet.class);
        String output = response.toString();
        log.info(output);
        return response;
    }

    public List<Pet> getAllPets(){
        URI uri = URI.create("http://localhost:8082/help/pet/getAllPets");
        List<Pet> response = restTemplate.getForObject(uri, List.class);
        String output = response.toString();
        log.info(output);
        return response;
    }
}