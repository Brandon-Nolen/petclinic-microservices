package com.example.petclinic.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.net.URI;
import java.util.List;

import com.example.petclinic.model.Visit;


@Service
public class VisitService {

    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public VisitService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Visit saveVisit(Visit visit) {
        URI uri = URI.create("http://localhost:8084/help/visit/addVisit");

        Visit response = restTemplate.postForObject(uri, visit, Visit.class);
        String output = response.toString();
        log.info(output);
        return response;
    }

    public List<Visit> getAllVisits(){
        URI uri = URI.create("http://localhost:8084/help/visit/getAllVisits");
        List<Visit> response = restTemplate.getForObject(uri, List.class);
        String output = response.toString();
        log.info(output);
        return response;
    }

}