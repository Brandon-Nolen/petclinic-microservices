package com.example.petclinic.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.net.URI;
import java.util.List;

import com.example.petclinic.model.Vet;


@Service
public class VetService {

    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public VetService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Vet saveVet(Vet vet) {
        URI uri = URI.create("http://localhost:8083/help/vet/addVet");

        Vet response = restTemplate.postForObject(uri, vet, Vet.class);
        String output = response.toString();
        log.info(output);
        return response;
    }

    public List<Vet> getAllVets(){
        URI uri = URI.create("http://localhost:8083/help/vet/getAllVets");
        List<Vet> response = restTemplate.getForObject(uri, List.class);
        String output = response.toString();
        log.info(output);
        return response;
    }

}