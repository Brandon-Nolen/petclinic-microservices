package com.example.petclinic.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.net.URI;
import java.util.List;

import com.example.petclinic.model.Owner;


@Service
public class OwnerService {

    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Owner saveOwner(Owner owner) {
        URI uri = URI.create("http://localhost:8085/help/owner/addOwner");

        Owner response = restTemplate.postForObject(uri, owner, Owner.class);
        String output = response.toString();
        log.info(output);
        return response;
    }

    public Owner getById(Long id) {
        String url = "http://localhost:8085/help/owner/getById/" + id;
        Owner response = restTemplate.getForObject(url,Owner.class);
        String output = response.toString();
        log.info(output);
        return response;
    }


    public List<Owner> getAllOwners(){
        URI uri = URI.create("http://localhost:8085/help/owner/getAllOwners");
        List<Owner> response = restTemplate.getForObject(uri, List.class);
        String output = response.toString();
        log.info(output);
        return response;
    }


}
